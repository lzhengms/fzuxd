使用AngularJs开发Web应用
=======================

*  前端样式：bootstrap
*  模版引擎：angularjs

如何启动app：
--------------------------------------
*  进入demo，在node环境下，运行server.js文件：node server，
   访问页面：http://127.0.0.1:8080/app/index.html





