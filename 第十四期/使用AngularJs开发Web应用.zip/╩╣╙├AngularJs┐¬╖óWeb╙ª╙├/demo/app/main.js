var schoolApp = angular.module("school", ["ngRoute"])
//    模块：config
    .config(["$routeProvider",
        function ($routeProvider) {
            $routeProvider
                .when('/', {//默认首页
                    templateUrl: 'partials/list.html',
                    controller: 'ListCtrl'
                })
                .when('/detail/:orderid', {//详情
                    templateUrl: 'partials/detail.html',
                    controller: 'DetailCtrl'
                })
            $routeProvider.otherwise({redirectTo: '/'});
        }])
    .constant("WebConfig", {
        "version": "1.3.0",
        "auth": "runchicken"
    })
    .controller("ListCtrl", ["$scope", "$http", "WebConfig", "Order",
        function ($scope, $http, WebConfig, Order) {
            $scope.WebConfig = WebConfig;
            $scope.Order = Order;
            Order.list($scope);
        }])
    .controller("DetailCtrl", ["$scope", "Order",
        function ($scope, Order) {
            Order.detail($scope);
        }])
    .factory("Order", ["$rootScope", "$http" , "$routeParams",
        function ($scope, $http, $routeParams) {//order管理服务
            var Order = {};
            Order.list = function (scope) {
                $http({method: 'GET', url: 'json/orders.json?' + $routeParams.orderid})
                    .success(function (data) {
                        scope.orders = data.DATA.OrderList;
                    });
            };
            Order.detail = function (scope) {
                $http({method: 'GET', url: 'json/order.json?' + $routeParams.orderid})
                    .success(function (data) {
                        $scope.order = data.DATA.Order;
                    });
            };
            Order.delete = function (scope, index) {
                scope.orders.splice(index, 1);
            }
            Order.add = function (scope, order) {
                order.createTime = new Date().getTime()/1000;
                scope.orders.push(order);
                scope.order = {};
            }
            return Order;
        }])
    .filter('status', function () {
        return function (sta) {//状态
            var status = "";
            switch (sta) {
                case 'much':
                    status = '存货很多';
                    break;
                case 'none':
                    status = '无货';
                    break;
                case 'less':
                    status = '少量现货';
                    break;
                default:
                    status = '其他';
                    break;
            }
            return status;
        };
    })