module.exports = function(grunt) {

	// 任务配置
	grunt.initConfig({
		compass: {
			dev: {
				options: {
					sassDir: 'sass',
					cssPath: 'css',
					imagesPath: 'img'
				}
			}
		},
		autoprefixer: {
			options: {
				diff: true,
				map: true
			},
			dist: {
				files: [{
					expand: true,
					cwd: 'css',
					src: ['*.css'],
					dest: 'css'
				}]
			}
		},
		watch: {
			all: {
				files: ['sass/*', 'coffee/*'],
				tasks: ['build']
			},
			livereload: {
				options: {
					livereload: true,
				},
				files: [
					'index.html',
					'css/*',
					'js/*'
				]
			}
		},
		connect: {
			livereload_server: {
				options: {
					port: '9001',
					livereload: true
				}
			}
		}
	});

	// 载入任务模块
	grunt.loadNpmTasks('grunt-contrib-watch');
	grunt.loadNpmTasks('grunt-contrib-connect');
	grunt.loadNpmTasks('grunt-contrib-compass');

	// 自定义任务组
	grunt.registerTask('build', [
		'compass'
	]);

	grunt.registerTask('default', [
		'build',
		'connect', 
		'watch',
	]);
};