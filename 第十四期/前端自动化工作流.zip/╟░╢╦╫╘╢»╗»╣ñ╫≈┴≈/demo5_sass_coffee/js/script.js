(function() {
  var cubes, i, list, math, num, number, opposite, square, _i, _len;

  number = 42;

  opposite = true;

  if (opposite) {
    number = -42;
  }

  square = function(x) {
    return x * x;
  };

  list = [1, 2, 3, 4, 5];

  for (_i = 0, _len = list.length; _i < _len; _i++) {
    i = list[_i];
    console.log(i);
  }

  math = {
    root: Math.sqrt,
    square: square,
    cube: function(x) {
      return x * square(x);
    }
  };

  cubes = (function() {
    var _j, _len1, _results;
    _results = [];
    for (_j = 0, _len1 = list.length; _j < _len1; _j++) {
      num = list[_j];
      _results.push(math.cube(num));
    }
    return _results;
  })();

  console.log(cubes);

}).call(this);
