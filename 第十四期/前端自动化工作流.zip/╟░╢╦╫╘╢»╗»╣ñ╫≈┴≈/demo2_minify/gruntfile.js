module.exports = function(grunt) {

	// 任务配置
	grunt.initConfig({
		concat: {
			js: {
				src: ['js/foo.js', 'js/bar.js'],
				dest: 'dist/build.js'
			},
			css: {
				src: ['css/foo.css', 'css/bar.css'],
				dest: 'dist/build.css'	
			}
		},
		cssmin: {
			options: {
				banner: '/* cssmin */'
			},
			all: {
				src: ['dist/build.css'],
				dest: 'dist/build.min.css'
			}
		},
		uglify: {
			options: {
				banner: '/* uglify */\n'
			},
			all: {
				src: ['dist/build.js'],
				dest: 'dist/build.min.js'
			}
		}
	});

	// 载入任务模块
	grunt.loadNpmTasks('grunt-contrib-concat');
	grunt.loadNpmTasks('grunt-contrib-cssmin');
	grunt.loadNpmTasks('grunt-contrib-uglify');

	// 自定义任务组
	grunt.registerTask('default', [
		'concat', 
		'cssmin',
		'uglify'
	]);

};