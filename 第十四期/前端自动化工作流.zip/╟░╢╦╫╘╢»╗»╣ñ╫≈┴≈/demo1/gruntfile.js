module.exports = function(grunt) {

	// 任务配置
	grunt.initConfig({
		concat: {
			mytask: {
				src: ['js/foo.js', 'js/bar.js'],
				dest: 'dist/build.js'
			}
		}
	});

	// 载入任务模块
	grunt.loadNpmTasks('grunt-contrib-concat');

	// 自定义任务组
	grunt.registerTask('default', ['concat']);

};